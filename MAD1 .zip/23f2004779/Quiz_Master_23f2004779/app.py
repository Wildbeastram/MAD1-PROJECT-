# Import necessary modules
from flask import Flask
from backend.models import db, User  # Ensure User model is imported
from flask_login import LoginManager
from datetime import datetime


# Initialize Flask app
app = Flask(__name__)
app.debug = True

# Configure database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Quizmaster_app.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'my_very_secret_key'  # Ensure secret key is set

# Initialize database
db.init_app(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'  # Redirect users to login page if not logged in

#Load user function for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))  # Fetch user from the database

# Create tables in the database
with app.app_context():
    db.create_all()
    print("Database tables created successfully!")

# Import and register routes
from backend.controller import register_routes
register_routes(app)  # Pass the app instance

@app.template_filter('datetimeformat')
def datetimeformat(value, format='%Y-%m-%d %H:%M'):
    if isinstance(value, datetime):
        return value.strftime(format)
    return value  # If it's already a string, return as is

# Run the app
if __name__ == '__main__':
    app.run(debug=True)

# Function to add admin for my viva
def add_admin(name, email, password):
    """Directly adding an admin user to the database."""
    
    # Check if the admin already exists
    existing_admin = User.query.filter_by(email=email).first()
    
    if existing_admin:
        print(f"Admin with email {email} already exists.")
        return

    # Create the admin user (role=0 for admin)
    new_admin = User(name=name, email=email, password=password, role=0)
    
    # Add and commit the new admin to the database
    db.session.add(new_admin)
    db.session.commit()
    print(f"Admin user {name} added successfully.")

# Example usage (only when running this script directly)
if __name__ == "__main__":
    with app.app_context():  # Ensures the app context is active for database operations
        add_admin("AdminName", "admin@gmail.com", "admin")

