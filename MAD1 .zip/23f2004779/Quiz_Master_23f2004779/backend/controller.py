from flask import Flask, render_template, request, redirect, url_for, session, flash
from backend.models import db, User, Quiz, Question, Score, Subject, AddChapter,Quiz,Score
from flask_login import login_required, current_user
from datetime import datetime


def register_routes(app):  # Accept app as an argument
    
    @app.route('/')
    def home():
        return render_template("login.html")
    
    # Login Route
    from flask_login import login_user

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            uname = request.form['email']
            pwd = request.form['password']
            
            usr = User.query.filter_by(email=uname, password=pwd).first()  # Fetch user
            
            if usr:
                login_user(usr)  # ✅ Log the user in
                session['username'] = usr.name  # ✅ Store username in session

                if usr.role == 0:  # Admin user
                    return redirect(url_for('admin_dashboard', name=usr.name))
                elif usr.role == 1:  # Normal user
                    return redirect(url_for('user_dashboard', name=usr.name))

            return render_template("login.html", msg="Invalid User credentials!")

        return render_template("login.html", msg="")

    
    # Registration Route
    @app.route('/register', methods=['GET', 'POST'])
    def signup():
        if request.method == 'POST':
            full_name = request.form['name']
            Email = request.form['email']
            pwd = request.form['password']
            qualification = request.form.get('Qualification')
            dob = request.form['DOB']

            # Check if the email is already registered
            existing_user = User.query.filter_by(email=Email).first()
            
            if existing_user:
                return render_template("signup.html", msg="User Already Exists")

            # If not, create and save the new user
            new_user = User(name=full_name, email=Email, password=pwd, Qualification=qualification, DOB=dob)
            db.session.add(new_user)
            db.session.commit()
            
            return render_template("login.html", msg="Registered Successfully, You can Login now.")

        return render_template("signup.html", msg="")

    
    # Admin Dashboard
    @app.route('/admin/<name>')
    def admin_dashboard(name):
        subjects = get_subjects()
        if not subjects:
            print("No subjects found.")
        return render_template("admin_dashboard.html", name=name, subjects=subjects)
    
    # User Dashboard
    @app.route('/user/<name>', methods=['GET', 'POST'])
    @login_required
    def user_dashboard(name):

        subjects = Subject.query.options(db.joinedload(Subject.chapters).joinedload(AddChapter.questions)).all()
        quizzes = Quiz.query.all()  # Fetch all quizzes
        return render_template("user_dashboard.html", name=name, subjects=subjects, quizzes=quizzes)


    
    # Add Subject Route
    @app.route('/addsubject/<name>', methods=['GET', 'POST'])
    def addsubject(name):
        if request.method == 'POST':
            subjectname = request.form.get('subname')
            subject_description = request.form['subdesc']
            
            subj = Subject(subjectname=subjectname, sub_description=subject_description)
            db.session.add(subj)
            db.session.commit()
            
            return redirect(url_for('admin_dashboard', name=name))
        
        return render_template("Add_Subjects.html", name=name)
    
    @app.route('/view_chapter/<int:id>')
    def view_chapter(id):
        chapter = AddChapter.query.get(id)
        if not chapter:
            return "Chapter not found", 404
        return render_template("view_chapter.html", chapter=chapter)

    # Add Chapter Route
    @app.route('/addchapter/<int:subject_id>/<name>', methods=['GET', 'POST'])
    def addchapter(subject_id, name):
        subjects = Subject.query.all()

        if request.method == 'POST':
            chapter_name = request.form.get('chapter_name')

            if not chapter_name:
                flash("Chapter name is required!", "danger")
                return redirect(url_for('addchapter', subject_id=subject_id, name=name))

            #  Creating a new chapter linked to the subject
            new_chap = AddChapter(chapterName=chapter_name, subjectid=subject_id)
            db.session.add(new_chap)
            db.session.commit()


            flash("Chapter and Quiz added successfully!", "success")
            return redirect(url_for('admin_dashboard', name=name))

        return render_template("add_chapter.html", name=name, subject_id=subject_id, subjects=subjects)




    
    # Function to get all subjects
    def get_subjects():
        return Subject.query.all()
    
    # Search Functionality
    @app.route('/search/<name>', methods=['GET', 'POST'])
    def search(name):
        if request.method == 'POST':
            search_txt = request.form.get('search_txt')
            by_chapter = search_by_chapter(search_txt)
            by_subject = search_by_subject(search_txt)
            
            if by_subject:
                return render_template("admin_dashboard.html", name=name, subjects=by_subject)
            elif by_chapter:
                return render_template("admin_dashboard.html", name=name, chapters=by_chapter)
        
        return redirect(url_for('admin_dashboard', name=name))
    


    # Edit Subject Route
    @app.route('/edit_subject/<id>/<name>', methods=['GET', 'POST'])
    def edit_subject(id, name):
        subject = get_subject(id)
        
        if request.method == 'POST':
            subjectname = request.form.get('subname')
            subject_description = request.form['subdesc']
            
            subject.subjectname = subjectname
            subject.sub_description = subject_description
            db.session.commit()
            
            return redirect(url_for('admin_dashboard', name=name))
        
        return render_template("Edit_Subjects.html", Subject=subject, name=name)
    
    @app.route('/edit_chapter/<id>/<name>', methods=['GET', 'POST'])
    def edit_chapter(id, name):
        chapter = get_chapter(id)

        if request.method == 'POST':
            chapterName = request.form.get('chapname')
            Qsn = request.form['qsn']

            
            chapter.chapterName = chapterName
            chapter.Qsn = Qsn
            db.session.commit()
            
            return redirect(url_for('admin_dashboard', name=name))
        
        return render_template("Edit_chapter.html", chapter=chapter, name=name)
    
    # Delete Subject Route
    @app.route('/delete_subject/<int:id>/<name>', methods=['GET','POST'])
    def delete_subject(id, name):
        subject = Subject.query.get_or_404(id)

        if subject:
            # Delete related chapters and quizzes
            chapters = AddChapter.query.filter_by(subjectid=id).all()
            for chapter in chapters:
                quizzes = Quiz.query.filter_by(chapter_id=chapter.id).all()
                for quiz in quizzes:
                    Score.query.filter_by(quiz_id=quiz.id).delete()
                    db.session.delete(quiz)

                db.session.delete(chapter)

            db.session.delete(subject)
            db.session.commit()

        return redirect(url_for('admin_dashboard', name=name))  

    
    # Delete Chapter Route
    @app.route('/delete_chapter/<int:chapter_id>/<name>', methods=['GET','POST'])
    def delete_chapter(chapter_id, name):
        chapter = AddChapter.query.get_or_404(chapter_id)
        
        quiz = Quiz.query.filter_by(chapter_id=chapter.id).first()

        if quiz:
           
            Score.query.filter_by(quiz_id=quiz.id).delete()

            db.session.delete(quiz)

        db.session.delete(chapter)
        db.session.commit()
        
        flash("Chapter, related quiz, and scores deleted successfully!", "success")
        return redirect(url_for('admin_dashboard', name=name))



    # Function to search subjects
    def search_by_subject(search_txt):
        return Subject.query.filter(Subject.subjectname.ilike(f"%{search_txt}%")).all()
    
    # Function to search chapters
    def search_by_chapter(search_txt):
        return AddChapter.query.filter(AddChapter.chapterName.ilike(f"%{search_txt}%")).all()
    
    # Function to get a single subject by ID
    def get_subject(id):
        return Subject.query.get(id)
    
    # Function to get a single chapter by ID    
    def get_chapter(id):
        return AddChapter.query.get(id)

    @app.route('/add_question/<int:chapter_id>/<string:name>', methods=['GET', 'POST'])
    def add_question(chapter_id,name):
        chapter = AddChapter.query.get_or_404(chapter_id)

        if request.method == 'POST':
            # Validate form data
            if 'question_text' not in request.form or not request.form['question_text']:
                flash("Missing question text!", "danger")
                return redirect(url_for('add_question', chapter_id=chapter_id, name=name))

            new_question = Question(
                chapter_id=chapter.id,
                question_text=request.form['question_text'],
                option_a=request.form['option_a'],
                option_b=request.form['option_b'],
                option_c=request.form['option_c'],
                option_d=request.form['option_d'],
                correct_option=request.form['correct_option'].lower()
            )
            db.session.add(new_question)
            db.session.commit()
            flash("Question added successfully!", "success")

            # Redirect to the add question page to reflect changes
            return redirect(url_for('admin_dashboard', name=name))  

        # Fetch all subjects and chapters for display
        all_subjects = Subject.query.options(db.joinedload(Subject.chapters).joinedload(AddChapter.questions)).all()

        return render_template('add_question.html', all_subjects=all_subjects, chapter_id=chapter_id)

#  Edit Question Route
    @app.route('/edit_question/<int:question_id>/<string:name>',methods=['GET', 'POST'])
    def edit_question(question_id, name):
        question = Question.query.get_or_404(question_id)

        if question:
            question.question_text = request.form['question_text']
            question.option_a = request.form['option_a']
            question.option_b = request.form['option_b']
            question.option_c = request.form['option_c']
            question.option_d = request.form['option_d']
            question.correct_option = request.form['correct_option'].lower()

            db.session.commit()
            flash("Question updated successfully!", "info")

        return redirect(url_for('admin_dashboard', name=name)) 



# Fix Delete Question Route

    @app.route('/delete_question/<int:question_id>/<string:name>', methods=['GET', 'POST'])
    def delete_question(question_id, name):
        question = Question.query.get_or_404(question_id)

        if question:
            db.session.delete(question)
            db.session.commit()
            flash("Question removed successfully!", "danger")

        return redirect(url_for('admin_dashboard', name=name)) 
    #Start Quiz Route
    @app.route('/quiz/<int:quiz_id>/start', methods=['GET'])
    @login_required
    def start_quiz(quiz_id):
        quiz = Quiz.query.get_or_404(quiz_id)
        
        if not quiz:
            flash("No quiz found!", "danger")
            return redirect(url_for('user_dashboard', name=session.get('username')))

        chapter = AddChapter.query.get(quiz.chapter_id)
        subject = Subject.query.get(chapter.subjectid)


        questions = Question.query.filter_by(chapter_id=chapter.id).all()

        return render_template('quiz.html', quiz=quiz, chapter=chapter, subject=subject, questions=questions)


    #Submit Quiz Route
    @app.route('/quiz/<int:quiz_id>/submit', methods=['POST'])
    @login_required
    def submit_quiz(quiz_id):
        quiz = Quiz.query.get_or_404(quiz_id)
        questions = Question.query.filter_by(chapter_id=quiz.chapter_id).all()

        score = 0
        for question in questions:
            selected_option = request.form.get(f"question_{question.id}")
            if selected_option == question.correct_option:
                score += 1 #adding marks/score for each correct answer.

        new_score = Score(user_id=current_user.id, quiz_id=quiz.id, total_scored=score)
        db.session.add(new_score)
        db.session.commit()

        flash(f"Quiz Submitted! You scored {score}/{len(questions)}", "success")
        return redirect(url_for('user_dashboard', name=current_user.name))

    
    
    @app.route('/scores')
    @login_required  #Only logged-in users can view scores
    def view_scores():
        user_scores = Score.query.filter_by(user_id=current_user.id).all()
        return render_template('scores.html', scores=user_scores)


    @app.route('/summary')
    @login_required
    def summary():
        user_id = current_user.id  # Get the logged-in user’s ID

        # Retrieve all quiz attempts by the user
        user_scores = Score.query.filter_by(user_id=user_id).all()

        # Compute statistics
        total_attempts = len(user_scores)
        avg_score = round(sum(score.total_scored for score in user_scores) / total_attempts, 2) if total_attempts > 0 else 0
        highest_score = max(user_scores, key=lambda x: x.total_scored).total_scored if user_scores else 0
        lowest_score = min(user_scores, key=lambda x: x.total_scored).total_scored if user_scores else 0

        return render_template(
            'summary.html',
            total_attempts=total_attempts,
            avg_score=avg_score,
            highest_score=highest_score,
            lowest_score=lowest_score,
            scores=user_scores
        )
    @app.route('/quiz/<int:quiz_id>/view', methods=['GET'])
    @login_required
    def view_quiz_details(quiz_id):
        quiz = Quiz.query.get_or_404(quiz_id)
        chapter = AddChapter.query.get_or_404(quiz.chapter_id)
        subject = Subject.query.get_or_404(chapter.subjectid)
        questions = Question.query.filter_by(chapter_id=chapter.id).all()

        return render_template('view_quiz.html', quiz=quiz, chapter=chapter, subject=subject, questions=questions)

    @app.route('/quiz_management/<name>')
    def quiz_management(name):
        quizzes = Quiz.query.all()  # Fetch all quizzes
        chapters = AddChapter.query.all()  # Fetch all chapters
        subjects = Subject.query.all()  # Fetch all subjects
        return render_template('quiz_management.html', quizzes=quizzes, chapters=chapters, subjects=subjects,name=name)


    @app.route('/add_quiz/<name>', methods=['GET', 'POST'])
    def add_quiz(name):
        if request.method == 'POST':
            chapter_id = request.form.get('chapter_id')
            time_duration = request.form.get('time_duration')
            quiz_date = request.form.get('date_of_quiz')
            
            new_quiz = Quiz(chapter_id=chapter_id, time_duration=time_duration, date_of_quiz=datetime.strptime(quiz_date, '%Y-%m-%dT%H:%M'))
            db.session.add(new_quiz)
            db.session.commit()
            
            print(f"Added Quiz for Chapter: {chapter_id}, Date: {quiz_date}")  # Debugging statement
            flash('Quiz added successfully!', 'success')
            return redirect(url_for('quiz_management',name=name))
        
        chapters = AddChapter.query.all()
        return render_template('add_quiz.html', chapters=chapters,name=name)


    @app.route('/editquiz/<int:quiz_id>/<name>', methods=['GET', 'POST'])
    def edit_quiz(quiz_id, name):
        quiz = Quiz.query.get_or_404(quiz_id)

        if request.method == 'POST':
            time_duration = request.form.get('time_duration')
            date_of_quiz = request.form.get('date_of_quiz')

            if not time_duration or not date_of_quiz:
                flash("Quiz duration and date are required!", "danger")
                return redirect(url_for('edit_quiz', quiz_id=quiz_id, name=name))

            #  Handle cases where the input is missing time (assume midnight)
            try:
                if "T" in date_of_quiz:
                    quiz.date_of_quiz = datetime.strptime(date_of_quiz, '%Y-%m-%dT%H:%M')  # Full datetime format
                else:
                    quiz.date_of_quiz = datetime.strptime(date_of_quiz, '%Y-%m-%d')  # Date-only format
            except ValueError:
                flash("Invalid date format! Please enter a valid date.", "danger")
                return redirect(url_for('edit_quiz', quiz_id=quiz_id, name=name))

            quiz.time_duration = int(time_duration)
            db.session.commit()

            flash("Quiz updated successfully!", "success")
            return redirect(url_for('admin_dashboard', name=name))

        return render_template("edit_quiz.html", quiz=quiz, name=name)


    @app.route('/delete_quiz/<int:quiz_id>/<name>', methods=['POST'])
    def delete_quiz(quiz_id,name):
        quiz = Quiz.query.get_or_404(quiz_id)

        #  Delete all scores related to this quiz first
        if quiz:
            Score.query.filter_by(quiz_id=quiz.id).delete()

            db.session.delete(quiz)
            db.session.commit()


        flash("Quiz and related scores deleted successfully!", "success")
        return redirect(url_for('quiz_management',name=name))

