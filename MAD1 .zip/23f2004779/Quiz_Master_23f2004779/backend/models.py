from flask_sqlalchemy import SQLAlchemy 
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

class User(db.Model,UserMixin):
    __tablename__ = "user_info"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False, unique=True)
    Qualification = db.Column(db.String, nullable=True)
    email = db.Column(db.String, nullable=False)
    password = db.Column(db.String, nullable=False)
    role = db.Column(db.Integer, nullable=False, default=1)
    DOB = db.Column(db.String, nullable=True) 



class Subject(db.Model):
    __tablename__ = "subject"
    id = db.Column(db.Integer, primary_key=True,nullable=True)
    subjectname = db.Column(db.String, nullable=False)
    sub_description = db.Column(db.String, nullable=False)
    chapters = db.relationship('AddChapter', backref='subject', lazy=True)#subject can access all of its chapters


class AddChapter(db.Model):
    __tablename__ = "addchapter"
    id = db.Column(db.Integer, primary_key=True)
    chapterName = db.Column(db.String(100), nullable=False)
    Qsn = db.Column(db.Integer, nullable=False, default=0)
    quiz = db.relationship("Quiz", uselist=False, backref="chapter", cascade="all, delete")

    subjectid = db.Column(db.Integer, db.ForeignKey('subject.id',ondelete="CASCADE"), nullable=False)

class Question(db.Model):
    __tablename__ = "question"
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id',ondelete="CASCADE"))  # FIXED Foreign Key
    question_text = db.Column(db.String(250), nullable=False)
    option_a = db.Column(db.String(250), nullable=False)
    option_b = db.Column(db.String(250), nullable=False)
    option_c = db.Column(db.String(250), nullable=False)
    option_d = db.Column(db.String(250), nullable=False)
    correct_option = db.Column(db.String(1), nullable=False)  # a, b, c, or d
    chapter_id = db.Column(db.Integer, db.ForeignKey('addchapter.id',ondelete="CASCADE"), nullable=False)
    
    chapter = db.relationship('AddChapter', backref=db.backref('questions', lazy=True,cascade="all, delete"))



class Quiz(db.Model):
    __tablename__ = "quiz"
    id = db.Column(db.Integer, primary_key=True)
    chapter_id = db.Column(db.Integer, db.ForeignKey('addchapter.id'), nullable=False, unique=True)  # ✅ Ensure One-to-One relationship
    date_of_quiz = db.Column(db.DateTime, default=datetime.utcnow)
    time_duration = db.Column(db.Integer)  # Time in minutes
    questions = db.relationship('Question', backref='quiz', lazy=True)  # Link questions

class Score(db.Model):
    __tablename__ = "score"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user_info.id'), nullable=False)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    timestamp  = db.Column(db.DateTime, default=datetime.utcnow)
    total_scored = db.Column(db.Integer, nullable=False)
    user = db.relationship("User", backref="scores")
    quiz = db.relationship("Quiz", backref="scores")
