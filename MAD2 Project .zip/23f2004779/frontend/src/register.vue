<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { post, uploadForm } from '@/utils/api.js'
const router = useRouter()
const tab = ref('student')
const error = ref('')
const success = ref('')
const loading = ref(false)
const s = ref({ name: '', email: '', password: '', department: '', year: 1, cgpa: 0 })
const resumeFile = ref(null)
function onResumeChange(e) { resumeFile.value = e.target.files[0] || null }
const c = ref({ company_name: '', email: '', password: '', hr_contact: '', website: '' })
async function registerStudent() {
  error.value = ''
  success.value = ''
  if (!s.value.name || !s.value.email || !s.value.password) { error.value = 'Name, email, and password are required'; return }
  loading.value = true
  const fd = new FormData()
  fd.append('name', s.value.name)
  fd.append('email', s.value.email)
  fd.append('password', s.value.password)
  fd.append('department', s.value.department)
  fd.append('year', s.value.year)
  fd.append('cgpa', s.value.cgpa)
  if (resumeFile.value) fd.append('resume', resumeFile.value)
  const res = await uploadForm('POST', '/auth/register/student', fd)
  loading.value = false
  if (!res.ok) { error.value = res.data.msg || 'Registration failed'; return }
  success.value = res.data.msg
  setTimeout(() => router.push('/login'), 1500)
}
async function registerCompany() {
  error.value = ''
  success.value = ''
  if (!c.value.company_name || !c.value.email || !c.value.password) { error.value = 'Company name, email, and password are required'; return }
  loading.value = true
  const res = await post('/auth/register/company', c.value)
  loading.value = false
  if (!res.ok) { error.value = res.data.msg || 'Registration failed'; return }
  success.value = res.data.msg
  setTimeout(() => router.push('/login'), 1500)
}
</script>
<template>
<div class="auth-page">
  <div class="auth-card wide">
    <h2>Create Account</h2>
    <div class="tab-bar">
      <button :class="['tab-btn', tab === 'student' ? 'active' : '']" @click="tab = 'student'">Student</button>
      <button :class="['tab-btn', tab === 'company' ? 'active' : '']" @click="tab = 'company'">Company</button>
    </div>
    <div v-if="error" class="msg-error">{{ error }}</div>
    <div v-if="success" class="msg-success">{{ success }}</div>
    <div v-if="tab === 'student'" class="register-form">
      <div class="form-row">
        <div class="form-group"><label>Full Name</label><input v-model="s.name" placeholder="John Doe" /></div>
        <div class="form-group"><label>Email</label><input type="email" v-model="s.email" placeholder="you@example.com" /></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Password</label><input type="password" v-model="s.password" placeholder="Choose a password" /></div>
        <div class="form-group"><label>Department</label><input v-model="s.department" placeholder="Computer Science" /></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Year</label><input type="number" v-model.number="s.year" min="1" max="5" /></div>
        <div class="form-group"><label>CGPA</label><input type="number" v-model.number="s.cgpa" step="0.01" min="0" max="10" /></div>
      </div>
      <div class="form-group"><label>Resume (PDF, DOC, DOCX)</label><input type="file" accept=".pdf,.doc,.docx" @change="onResumeChange" /></div>
      <button class="btn-primary full" :disabled="loading" @click="registerStudent">{{ loading ? 'Registering...' : 'Register as Student' }}</button>
    </div>
    <div v-if="tab === 'company'" class="register-form">
      <div class="form-row">
        <div class="form-group"><label>Company Name</label><input v-model="c.company_name" placeholder="Acme Corp" /></div>
        <div class="form-group"><label>Email</label><input type="email" v-model="c.email" placeholder="hr@company.com" /></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Password</label><input type="password" v-model="c.password" placeholder="Choose a password" /></div>
        <div class="form-group"><label>HR Contact</label><input v-model="c.hr_contact" placeholder="+91 98765 43210" /></div>
      </div>
      <div class="form-group"><label>Website</label><input v-model="c.website" placeholder="https://company.com" /></div>
      <button class="btn-primary full" :disabled="loading" @click="registerCompany">{{ loading ? 'Registering...' : 'Register as Company' }}</button>
    </div>
    <p class="auth-link">Already have an account? <router-link to="/login">Sign in</router-link></p>
  </div>
</div>
</template>
