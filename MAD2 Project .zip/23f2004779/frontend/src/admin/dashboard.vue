<script setup>
import { ref, onMounted } from 'vue'
import { get, put, post } from '@/utils/api.js'
const stats = ref({})
const companies = ref([])
const students = ref([])
const drives = ref([])
const applications = ref([])
const activeTab = ref('overview')
const searchCompany = ref('')
const searchStudent = ref('')
const msg = ref('')
const msgType = ref('')
const modal = ref({ show: false, type: '', data: null })
const webhookModal = ref(false)
const webhookUrl = ref('')
function flash(text, type) { msg.value = text; msgType.value = type; setTimeout(() => { msg.value = '' }, 3000) }
async function loadStats() { const r = await get('/admin/stats'); if (r.ok) stats.value = r.data }
async function loadCompanies() { const r = await get('/admin/companies?search=' + searchCompany.value); if (r.ok) companies.value = r.data }
async function loadStudents() { const r = await get('/admin/students?search=' + searchStudent.value); if (r.ok) students.value = r.data }
async function loadDrives() { const r = await get('/admin/drives'); if (r.ok) drives.value = r.data }
async function loadApplications() { const r = await get('/admin/applications'); if (r.ok) applications.value = r.data }
async function approveCompany(id) { const r = await put('/admin/company/' + id + '/approve'); if (r.ok) { flash('Company approved', 'ok'); loadCompanies(); loadStats() } else flash(r.data.msg, 'err') }
async function rejectCompany(id) { const r = await put('/admin/company/' + id + '/reject'); if (r.ok) { flash('Company rejected', 'ok'); loadCompanies(); loadStats() } else flash(r.data.msg, 'err') }
async function toggleBlacklistCompany(id) { const r = await put('/admin/company/' + id + '/blacklist'); if (r.ok) { flash('Updated', 'ok'); loadCompanies() } else flash(r.data.msg, 'err') }
async function toggleBlacklistStudent(id) { const r = await put('/admin/student/' + id + '/blacklist'); if (r.ok) { flash('Updated', 'ok'); loadStudents() } else flash(r.data.msg, 'err') }
async function approveDrive(id) { const r = await put('/admin/drive/' + id + '/approve'); if (r.ok) { flash('Drive approved', 'ok'); loadDrives(); loadStats() } else flash(r.data.msg, 'err') }
async function rejectDrive(id) { const r = await put('/admin/drive/' + id + '/reject'); if (r.ok) { flash('Drive rejected', 'ok'); loadDrives(); loadStats() } else flash(r.data.msg, 'err') }
async function sendReminder() {
  if (!webhookUrl.value.trim()) { flash('Enter a webhook URL', 'err'); return }
  webhookModal.value = false
  const r = await post('/admin/reminder', { webhook_url: webhookUrl.value.trim() })
  flash(r.data.msg, r.ok ? 'ok' : 'err')
}
async function sendReport() { const r = await post('/admin/activity-report'); flash(r.data.msg, r.ok ? 'ok' : 'err') }
function openModal(type, data) { modal.value = { show: true, type, data } }
function closeModal() { modal.value = { show: false, type: '', data: null } }
function switchTab(t) { activeTab.value = t; if (t === 'companies') loadCompanies(); if (t === 'students') loadStudents(); if (t === 'drives') loadDrives(); if (t === 'applications') loadApplications() }
onMounted(() => { loadStats() })
</script>
<template>
<div class="dash admin-dash">
  <div v-if="msg" :class="['toast', msgType]">{{ msg }}</div>
  <div class="dash-header">
    <h1>Admin Dashboard</h1>
    <div class="dash-actions">
      <button class="btn-accent" @click="webhookUrl = ''; webhookModal = true">Send Reminder</button>
      <button class="btn-accent" @click="sendReport">Activity Report</button>
    </div>
  </div>
  <div class="tab-bar dash-tabs">
    <button :class="['tab-btn', activeTab === 'overview' ? 'active' : '']" @click="switchTab('overview')">Overview</button>
    <button :class="['tab-btn', activeTab === 'companies' ? 'active' : '']" @click="switchTab('companies')">Companies</button>
    <button :class="['tab-btn', activeTab === 'students' ? 'active' : '']" @click="switchTab('students')">Students</button>
    <button :class="['tab-btn', activeTab === 'drives' ? 'active' : '']" @click="switchTab('drives')">Drives</button>
    <button :class="['tab-btn', activeTab === 'applications' ? 'active' : '']" @click="switchTab('applications')">Applications</button>
  </div>
  <div v-if="activeTab === 'overview'" class="stat-grid">
    <div class="stat-card"><div class="stat-num">{{ stats.total_students || 0 }}</div><div class="stat-label">Students</div></div>
    <div class="stat-card"><div class="stat-num">{{ stats.total_companies || 0 }}</div><div class="stat-label">Companies</div></div>
    <div class="stat-card"><div class="stat-num">{{ stats.total_drives || 0 }}</div><div class="stat-label">Drives</div></div>
    <div class="stat-card"><div class="stat-num">{{ stats.total_applications || 0 }}</div><div class="stat-label">Applications</div></div>
    <div class="stat-card warn"><div class="stat-num">{{ stats.pending_companies || 0 }}</div><div class="stat-label">Pending Companies</div></div>
    <div class="stat-card warn"><div class="stat-num">{{ stats.pending_drives || 0 }}</div><div class="stat-label">Pending Drives</div></div>
  </div>
  <div v-if="activeTab === 'companies'">
    <div class="search-bar"><input v-model="searchCompany" placeholder="Search companies..." @input="loadCompanies" /></div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Name</th><th>HR Contact</th><th>Website</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          <tr v-for="co in companies" :key="co.id">
            <td>{{ co.company_name }}</td>
            <td>{{ co.hr_contact }}</td>
            <td><a :href="co.website" target="_blank">{{ co.website }}</a></td>
            <td><span :class="['badge', co.approval_status]">{{ co.approval_status }}</span></td>
            <td class="action-cell">
              <button v-if="co.approval_status === 'pending'" class="btn-sm ok" @click="approveCompany(co.id)">Approve</button>
              <button v-if="co.approval_status === 'pending'" class="btn-sm err" @click="rejectCompany(co.id)">Reject</button>
              <button class="btn-sm" :class="co.is_blacklisted ? 'ok' : 'warn'" @click="toggleBlacklistCompany(co.id)">{{ co.is_blacklisted ? 'Unblock' : 'Blacklist' }}</button>
            </td>
          </tr>
        </tbody>
      </table>
      <p v-if="companies.length === 0" class="empty">No companies found</p>
    </div>
  </div>
  <div v-if="activeTab === 'students'">
    <div class="search-bar  "><input v-model="searchStudent" placeholder="Search students..." @input="loadStudents" /></div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Name</th><th>Department</th><th>Year</th><th>CGPA</th><th>Actions</th></tr></thead>
        <tbody>
          <tr v-for="st in students" :key="st.id">
            <td>{{ st.student_name }}</td>
            <td>{{ st.department }}</td>
            <td>{{ st.year }}</td>
            <td>{{ st.cgpa }}</td>
            <td class="action-cell">
              <button class="btn-sm" @click="openModal('student', st)">View</button>
              <button class="btn-sm" :class="st.is_blacklisted ? 'ok' : 'warn'" @click="toggleBlacklistStudent(st.id)">{{ st.is_blacklisted ? 'Unblock' : 'Blacklist' }}</button>
            </td>
          </tr>
        </tbody>
      </table>
      <p v-if="students.length === 0" class="empty">No students found</p>
    </div>
  </div>
  <div v-if="activeTab === 'drives'">
    <div class="table-wrap">
      <table>
        <thead><tr><th>Title</th><th>Company</th><th>Deadline</th><th>Applicants</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          <tr v-for="dr in drives" :key="dr.id">
            <td>{{ dr.job_title }}</td>
            <td>{{ dr.company_name }}</td>
            <td>{{ dr.deadline ? dr.deadline.split('T')[0] : '-' }}</td>
            <td>{{ dr.applicant_count }}</td>
            <td><span :class="['badge', dr.status]">{{ dr.status }}</span></td>
            <td class="action-cell">
              <button class="btn-sm" @click="openModal('drive', dr)">View</button>
              <button v-if="dr.status === 'pending'" class="btn-sm ok" @click="approveDrive(dr.id)">Approve</button>
              <button v-if="dr.status === 'pending'" class="btn-sm err" @click="rejectDrive(dr.id)">Reject</button>
            </td>
          </tr>
        </tbody>
      </table>
      <p v-if="drives.length === 0" class="empty">No drives found</p>
    </div>
  </div>
  <div v-if="activeTab === 'applications'">
    <div class="table-wrap">
      <table>
        <thead><tr><th>Student</th><th>Drive</th><th>Company</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
          <tr v-for="ap in applications" :key="ap.id">
            <td>{{ ap.student_name }}</td>
            <td>{{ ap.drive_title }}</td>
            <td>{{ ap.company_name }}</td>
            <td><span :class="['badge', ap.status]">{{ ap.status }}</span></td>
            <td>{{ ap.date ? ap.date.split('T')[0] : '-' }}</td>
          </tr>
        </tbody>
      </table>
      <p v-if="applications.length === 0" class="empty">No applications found</p>
    </div>
  </div>
  <div v-if="modal.show" class="modal-overlay" @click.self="closeModal">
    <div class="modal-box">
      <button class="modal-close" @click="closeModal">&times;</button>
      <div v-if="modal.type === 'student'">
        <h3>Student Details</h3>
        <div class="detail-row"><span>Name</span><span>{{ modal.data.student_name }}</span></div>
        <div class="detail-row"><span>Department</span><span>{{ modal.data.department }}</span></div>
        <div class="detail-row"><span>Year</span><span>{{ modal.data.year }}</span></div>
        <div class="detail-row"><span>CGPA</span><span>{{ modal.data.cgpa }}</span></div>
        <div class="detail-row"><span>Resume</span><span v-if="modal.data.resume_path"><a :href="'http://localhost:5000/uploads/resumes/' + modal.data.resume_path" target="_blank">View Resume</a></span><span v-else>Not uploaded</span></div>
        <div class="detail-row"><span>Blacklisted</span><span>{{ modal.data.is_blacklisted ? 'Yes' : 'No' }}</span></div>
      </div>
      <div v-if="modal.type === 'drive'">
        <h3>Drive Details</h3>
        <div class="detail-row"><span>Title</span><span>{{ modal.data.job_title }}</span></div>
        <div class="detail-row"><span>Company</span><span>{{ modal.data.company_name }}</span></div>
        <div class="detail-row"><span>Description</span><span>{{ modal.data.job_description }}</span></div>
        <div class="detail-row"><span>Eligibility</span><span>{{ modal.data.eligibility_criteria }}</span></div>
        <div class="detail-row"><span>Deadline</span><span>{{ modal.data.deadline ? modal.data.deadline.split('T')[0] : '-' }}</span></div>
        <div class="detail-row"><span>Status</span><span>{{ modal.data.status }}</span></div>
        <div class="detail-row"><span>Applicants</span><span>{{ modal.data.applicant_count }}</span></div>
      </div>
    </div>
  </div>
  <div v-if="webhookModal" class="modal-overlay" @click.self="webhookModal = false">
    <div class="modal-box">
      <button class="modal-close" @click="webhookModal = false">&times;</button>
      <h3>Send Deadline Reminder</h3>
      <div class="form-group">
        <label>Google Chat Webhook URL</label>
        <input v-model="webhookUrl" type="url" placeholder="https://chat.googleapis.com/..." />
      </div>
      <button class="btn-accent" @click="sendReminder" style="margin-top:12px;width:100%">Send</button>
    </div>
  </div>
</div>
</template>
