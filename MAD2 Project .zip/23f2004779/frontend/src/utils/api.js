const BASE = "http://localhost:5000/api";
function getToken() {
  return localStorage.getItem("token") || "";
}
function headers(extra) {
  const h = { "Content-Type": "application/json" };
  const t = getToken();
  if (t) h["Authorization"] = "Bearer " + t;
  if (extra) Object.assign(h, extra);
  return h;
}
async function request(method, path, body) {
  const opts = { method, headers: headers() };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(BASE + path, opts);
  if (res.headers.get("content-type")?.includes("text/csv")) {
    const blob = await res.blob();
    return { ok: res.ok, status: res.status, blob };
  }
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
}
export function get(path) { return request("GET", path); }
export function post(path, body) { return request("POST", path, body); }
export function put(path, body) { return request("PUT", path, body); }
export async function uploadForm(method, path, formData) {
  const h = {};
  const t = getToken();
  if (t) h["Authorization"] = "Bearer " + t;
  const res = await fetch(BASE + path, { method, headers: h, body: formData });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
}
export function downloadCsv(path) {
  return fetch(BASE + path, { headers: headers() }).then(res => {
    if (!res.ok) throw new Error("Download failed");
    return res.blob();
  }).then(blob => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "placement_history.csv";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });
}
export function saveAuth(data) {
  localStorage.setItem("token", data.token);
  localStorage.setItem("role", data.role);
  localStorage.setItem("name", data.name);
  if (data.company_id) localStorage.setItem("company_id", data.company_id);
  if (data.student_id) localStorage.setItem("student_id", data.student_id);
}
export function getRole() { return localStorage.getItem("role") || ""; }
export function getName() { return localStorage.getItem("name") || ""; }
export function isLoggedIn() { return !!getToken(); }
export function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("role");
  localStorage.removeItem("name");
  localStorage.removeItem("company_id");
  localStorage.removeItem("student_id");
}