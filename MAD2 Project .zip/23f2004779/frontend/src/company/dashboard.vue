<script setup>
import { ref, onMounted } from 'vue'
import { get, post, put } from '@/utils/api.js'
const profile = ref({})
const drives = ref([])
const activeTab = ref('overview')
const msg = ref('')
const msgType = ref('')
const driveForm = ref({ job_title: '', job_description: '', eligibility_criteria: '', deadline: '' })
const showDriveForm = ref(false)
const applicants = ref([])
const selectedDrive = ref(null)
const loading = ref(false)
function flash(text, type) { msg.value = text; msgType.value = type; setTimeout(() => { msg.value = '' }, 3000) }
async function loadProfile() { const r = await get('/company/profile'); if (r.ok) profile.value = r.data }
async function loadDrives() { const r = await get('/company/drives'); if (r.ok) drives.value = r.data }
async function createDrive() {
  if (!driveForm.value.job_title) { flash('Job title is required', 'err'); return }
  loading.value = true
  const r = await post('/company/drives', driveForm.value)
  loading.value = false
  if (r.ok) { flash('Drive created', 'ok'); showDriveForm.value = false; driveForm.value = { job_title: '', job_description: '', eligibility_criteria: '', deadline: '' }; loadDrives() }
  else flash(r.data.msg, 'err')
}
async function viewApplicants(drive) {
  selectedDrive.value = drive
  const r = await get('/company/drive/' + drive.id + '/applications')
  if (r.ok) applicants.value = r.data
  activeTab.value = 'applicants'
}
async function updateStatus(aid, status) {
  const r = await put('/company/application/' + aid + '/status', { status })
  if (r.ok) { flash('Status updated', 'ok'); viewApplicants(selectedDrive.value) }
  else flash(r.data.msg, 'err')
}
function switchTab(t) { activeTab.value = t; if (t === 'drives') loadDrives() }
onMounted(() => { loadProfile(); loadDrives() })
</script>
<template>
<div class="dash company-dash">
  <div v-if="msg" :class="['toast', msgType]">{{ msg }}</div>
  <div class="dash-header">
    <h1>Company Dashboard</h1>
    <span :class="['badge', profile.approval_status]">{{ profile.approval_status }}</span>
  </div>
  <div class="tab-bar dash-tabs">
    <button :class="['tab-btn', activeTab === 'overview' ? 'active' : '']" @click="switchTab('overview')">Overview</button>
    <button :class="['tab-btn', activeTab === 'drives' ? 'active' : '']" @click="switchTab('drives')">My Drives</button>
    <button :class="['tab-btn', activeTab === 'applicants' ? 'active' : '']" v-if="selectedDrive" @click="activeTab = 'applicants'">Applicants</button>
  </div>
  <div v-if="activeTab === 'overview'" class="company-overview">
    <div class="profile-card">
      <h3>{{ profile.company_name }}</h3>
      <div class="detail-row"><span>Email</span><span>{{ profile.email }}</span></div>
      <div class="detail-row"><span>HR Contact</span><span>{{ profile.hr_contact }}</span></div>
      <div class="detail-row"><span>Website</span><span><a :href="profile.website" target="_blank">{{ profile.website }}</a></span></div>
      <div class="detail-row"><span>Status</span><span :class="['badge', profile.approval_status]">{{ profile.approval_status }}</span></div>
    </div>
    <div class="stat-grid sm">
      <div class="stat-card"><div class="stat-num">{{ drives.length }}</div><div class="stat-label">Total Drives</div></div>
      <div class="stat-card"><div class="stat-num">{{ drives.reduce((a, d) => a + d.applicant_count, 0) }}</div><div class="stat-label">Total Applicants</div></div>
    </div>
  </div>
  <div v-if="activeTab === 'drives'">
    <div class="section-header">
      <h3>Placement Drives</h3>
      <button class="btn-primary" @click="showDriveForm = !showDriveForm" v-if="profile.approval_status === 'approved'">{{ showDriveForm ? 'Cancel' : 'New Drive' }}</button>
    </div>
    <div v-if="showDriveForm" class="form-card">
      <div class="form-row">
        <div class="form-group"><label>Job Title</label><input v-model="driveForm.job_title" placeholder="Software Engineer" /></div>
        <div class="form-group"><label>Deadline</label><input type="datetime-local" v-model="driveForm.deadline" /></div>
      </div>
      <div class="form-group"><label>Job Description</label><textarea v-model="driveForm.job_description" rows="3" placeholder="Describe the role..."></textarea></div>
      <div class="form-group"><label>Eligibility (e.g. cgpa>=7, year>=3)</label><input v-model="driveForm.eligibility_criteria" placeholder="cgpa>=7, year>=3" /></div>
      <button class="btn-primary" :disabled="loading" @click="createDrive">{{ loading ? 'Creating...' : 'Create Drive' }}</button>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Title</th><th>Deadline</th><th>Status</th><th>Applicants</th><th>Actions</th></tr></thead>
        <tbody>
          <tr v-for="dr in drives" :key="dr.id">
            <td>{{ dr.job_title }}</td>
            <td>{{ dr.deadline ? dr.deadline.split('T')[0] : '-' }}</td>
            <td><span :class="['badge', dr.status]">{{ dr.status }}</span></td>
            <td>{{ dr.applicant_count }}</td>
            <td><button class="btn-sm" @click="viewApplicants(dr)">View Applicants</button></td>
          </tr>
        </tbody>
      </table>
      <p v-if="drives.length === 0" class="empty">No drives created yet</p>
    </div>
  </div>
  <div v-if="activeTab === 'applicants' && selectedDrive">
    <div class="section-header">
      <h3>Applicants for {{ selectedDrive.job_title }}</h3>
      <button class="btn-outline sm" @click="activeTab = 'drives'">Back to Drives</button>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Name</th><th>Department</th><th>Year</th><th>CGPA</th><th>Resume</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          <tr v-for="ap in applicants" :key="ap.id">
            <td>{{ ap.student_name }}</td>
            <td>{{ ap.department }}</td>
            <td>{{ ap.year }}</td>
            <td>{{ ap.cgpa }}</td>
            <td><a v-if="ap.resume_path" :href="'http://localhost:5000/uploads/resumes/' + ap.resume_path" target="_blank" class="btn-sm">View</a><span v-else>-</span></td>
            <td><span :class="['badge', ap.status]">{{ ap.status }}</span></td>
            <td class="action-cell">
              <select :value="ap.status" @change="updateStatus(ap.id, $event.target.value)">
                <option value="applied">Applied</option>
                <option value="shortlisted">Shortlisted</option>
                <option value="interview">Interview</option>
                <option value="selected">Selected</option>
                <option value="rejected">Rejected</option>
              </select>
            </td>
          </tr>
        </tbody>
      </table>
      <p v-if="applicants.length === 0" class="empty">No applicants yet</p>
    </div>
  </div>
</div>
</template>
