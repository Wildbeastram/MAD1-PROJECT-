<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { isLoggedIn, getRole } from '@/utils/api.js'
const router = useRouter()
const loggedIn = ref(isLoggedIn())
const role = ref(getRole())
const dashPath = computed(() => {
  if (role.value === 'admin') return '/admin'
  if (role.value === 'company') return '/company'
  if (role.value === 'student') return '/student'
  return '/login'
})
function goToDashboard() { router.push(dashPath.value) }
function goRegister() { router.push('/register') }
function goLogin() { router.push('/login') }
</script>
<template>
<div class="hero">
  <div class="hero-inner">
    <h1>Welcome to <span class="accent">CareerNexus</span></h1>
    <p class="hero-sub">Your gateway to campus placements. Connecting students, companies, and administrators on a single platform.</p>
    <div class="hero-actions">
      <template v-if="loggedIn">
        <button class="btn-primary" @click="goToDashboard">Go to Dashboard</button>
      </template>
      <template v-else>
        <button class="btn-primary" @click="goLogin">Login</button>
        <button class="btn-outline" @click="goRegister">Register</button>
      </template>
    </div>
  </div>
  <div class="features">
    <div class="feature-card">
      <div class="feature-icon">&#127891;</div>
      <h3>Students</h3>
      <p>Browse placement drives, apply with one click, and track your application status in real time.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">&#127970;</div>
      <h3>Companies</h3>
      <p>Post placement drives, manage applicants, shortlist candidates, and schedule interviews.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">&#128736;</div>
      <h3>Administrators</h3>
      <p>Oversee the entire platform, approve registrations, manage drives, and generate reports.</p>
    </div>
  </div>
</div>
</template>
