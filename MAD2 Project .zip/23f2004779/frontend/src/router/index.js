import { createRouter, createWebHistory } from 'vue-router'
import { isLoggedIn, getRole } from '@/utils/api.js'
import Home from '@/home.vue'
import Login from '@/login.vue'
import Register from '@/register.vue'
import AdminDashboard from '@/admin/dashboard.vue'
import CompanyDashboard from '@/company/dashboard.vue'
import StudentDashboard from '@/student/dashboard.vue'
const routes = [
  { path: '/', name: 'home', component: Home },
  { path: '/login', name: 'login', component: Login },
  { path: '/register', name: 'register', component: Register },
  { path: '/admin', name: 'admin', component: AdminDashboard, meta: { auth: true, role: 'admin' } },
  { path: '/company', name: 'company', component: CompanyDashboard, meta: { auth: true, role: 'company' } },
  { path: '/student', name: 'student', component: StudentDashboard, meta: { auth: true, role: 'student' } }
]
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})
router.beforeEach((to, from, next) => {
  if (to.meta.auth && !isLoggedIn()) return next('/login')
  if (to.meta.role && getRole() !== to.meta.role) return next('/')
  next()
})
export default router
