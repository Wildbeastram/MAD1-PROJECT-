<script setup>
import { ref, computed, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { isLoggedIn, getRole, getName, logout } from '@/utils/api.js'
import '@/assets/style.css'
const router = useRouter()
const route = useRoute()
const loggedIn = ref(isLoggedIn())
const role = ref(getRole())
const name = ref(getName())
watch(route, () => {
  loggedIn.value = isLoggedIn()
  role.value = getRole()
  name.value = getName()
})
const dashboardPath = computed(() => {
  if (role.value === 'admin') return '/admin'
  if (role.value === 'company') return '/company'
  if (role.value === 'student') return '/student'
  return '/'
})
function handleLogout() {
  logout()
  loggedIn.value = false
  role.value = ''
  name.value = ''
  router.push('/')
}
</script>
<template>
<div id="shell">
  <nav class="topbar">
    <router-link to="/" class="brand">CareerNexus</router-link>
    <div class="nav-links">
      <router-link to="/">Home</router-link>
      <template v-if="loggedIn">
        <router-link :to="dashboardPath">Dashboard</router-link>
        <span class="nav-user">{{ name }}</span>
        <button class="btn-nav" @click="handleLogout">Logout</button>
      </template>
      <template v-else>
        <router-link to="/login">Login</router-link>
        <router-link to="/register">Register</router-link>
      </template>
    </div>
  </nav>
  <main class="content">
    <router-view />
  </main>
  <footer class="app-footer">
    <span>CareerNexus</span>
  </footer>
</div>
</template>
