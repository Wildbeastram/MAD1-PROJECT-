<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { post, saveAuth } from '@/utils/api.js'
const router = useRouter()
const email = ref('')
const password = ref('')
const error = ref('')
const loading = ref(false)
async function handleLogin() {
  error.value = ''
  if (!email.value || !password.value) { error.value = 'Please fill in all fields'; return }
  loading.value = true
  const res = await post('/auth/login', { email: email.value, password: password.value })
  loading.value = false
  if (!res.ok) { error.value = res.data.msg || 'Login failed'; return }
  saveAuth(res.data)
  if (res.data.role === 'admin') router.push('/admin')
  else if (res.data.role === 'company') router.push('/company')
  else if (res.data.role === 'student') router.push('/student')
  else router.push('/')
}
</script>
<template>
<div class="auth-page">
  <div class="auth-card">
    <h2>Sign In</h2>
    <p class="auth-sub">Access your CareerNexus account</p>
    <div v-if="error" class="msg-error">{{ error }}</div>
    <div class="form-group">
      <label>Email</label>
      <input type="email" v-model="email" placeholder="you@example.com" @keyup.enter="handleLogin" />
    </div>
    <div class="form-group">
      <label>Password</label>
      <input type="password" v-model="password" placeholder="Enter password" @keyup.enter="handleLogin" />
    </div>
    <button class="btn-primary full" :disabled="loading" @click="handleLogin">
      {{ loading ? 'Signing in...' : 'Sign In' }}
    </button>
    <p class="auth-link">Don't have an account? <router-link to="/register">Register here</router-link></p>
  </div>
</div>
</template>
