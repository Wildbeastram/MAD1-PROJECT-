<script setup>
import { ref, onMounted } from 'vue'
import { get, post, put, downloadCsv, uploadForm } from '@/utils/api.js'
const BASE_URL = 'http://localhost:5000'
const profile = ref({})
const drives = ref([])
const applications = ref([])
const activeTab = ref('overview')
const searchDrive = ref('')
const msg = ref('')
const msgType = ref('')
const editMode = ref(false)
const editForm = ref({})
const loading = ref(false)
const modal = ref({ show: false, data: null })
const resumeFile = ref(null)
function onResumeChange(e) { resumeFile.value = e.target.files[0] || null }
function flash(text, type) { msg.value = text; msgType.value = type; setTimeout(() => { msg.value = '' }, 3000) }
async function loadProfile() { const r = await get('/student/profile'); if (r.ok) { profile.value = r.data; editForm.value = { name: r.data.student_name, department: r.data.department, year: r.data.year, cgpa: r.data.cgpa, resume_path: r.data.resume_path } } }
async function loadDrives() { const r = await get('/student/drives?search=' + searchDrive.value); if (r.ok) drives.value = r.data }
async function loadApplications() { const r = await get('/student/applications'); if (r.ok) applications.value = r.data }
async function updateProfile() {
  loading.value = true
  const fd = new FormData()
  fd.append('name', editForm.value.name)
  fd.append('department', editForm.value.department)
  fd.append('year', editForm.value.year)
  fd.append('cgpa', editForm.value.cgpa)
  if (resumeFile.value) fd.append('resume', resumeFile.value)
  const r = await uploadForm('PUT', '/student/profile', fd)
  loading.value = false
  if (r.ok) { flash('Profile updated', 'ok'); editMode.value = false; resumeFile.value = null; loadProfile() }
  else flash(r.data.msg, 'err')
}
async function applyDrive(did) {
  const r = await post('/student/apply/' + did)
  if (r.ok) { flash('Applied successfully', 'ok'); loadDrives(); loadApplications() }
  else flash(r.data.msg, 'err')
}
function exportCsv() { downloadCsv('/student/export-csv').catch(() => flash('Export failed', 'err')) }
function openDriveDetail(dr) { modal.value = { show: true, data: dr } }
function closeModal() { modal.value = { show: false, data: null } }
function switchTab(t) { activeTab.value = t; if (t === 'drives') loadDrives(); if (t === 'history') loadApplications() }
onMounted(() => { loadProfile(); loadDrives(); loadApplications() })
</script>
<template>
<div class="dash student-dash">
  <div v-if="msg" :class="['toast', msgType]">{{ msg }}</div>
  <div class="dash-header">
    <h1>Student Dashboard</h1>
    <button class="btn-accent" @click="exportCsv">Export CSV</button>
  </div>
  <div class="tab-bar dash-tabs">
    <button :class="['tab-btn', activeTab === 'overview' ? 'active' : '']" @click="switchTab('overview')">Profile</button>
    <button :class="['tab-btn', activeTab === 'drives' ? 'active' : '']" @click="switchTab('drives')">Drives</button>
    <button :class="['tab-btn', activeTab === 'history' ? 'active' : '']" @click="switchTab('history')">My Applications</button>
  </div>
  <div v-if="activeTab === 'overview'">
    <div class="profile-card" v-if="!editMode">
      <h3>{{ profile.student_name }}</h3>
      <div class="detail-row"><span>Email</span><span>{{ profile.email }}</span></div>
      <div class="detail-row"><span>Department</span><span>{{ profile.department }}</span></div>
      <div class="detail-row"><span>Year</span><span>{{ profile.year }}</span></div>
      <div class="detail-row"><span>CGPA</span><span>{{ profile.cgpa }}</span></div>
      <div class="detail-row"><span>Resume</span><span v-if="profile.resume_path"><a :href="BASE_URL + '/uploads/resumes/' + profile.resume_path" target="_blank">View Resume</a></span><span v-else>Not uploaded</span></div>
      <button class="btn-primary" @click="editMode = true">Edit Profile</button>
    </div>
    <div class="form-card" v-else>
      <h3>Edit Profile</h3>
      <div class="form-row">
        <div class="form-group"><label>Name</label><input v-model="editForm.name" /></div>
        <div class="form-group"><label>Department</label><input v-model="editForm.department" /></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Year</label><input type="number" v-model.number="editForm.year" min="1" max="5" /></div>
        <div class="form-group"><label>CGPA</label><input type="number" v-model.number="editForm.cgpa" step="0.01" min="0" max="10" /></div>
      </div>
      <div class="form-group"><label>Resume (PDF, DOC, DOCX)</label><input type="file" accept=".pdf,.doc,.docx" @change="onResumeChange" /></div>
      <div class="form-actions">
        <button class="btn-primary" :disabled="loading" @click="updateProfile">{{ loading ? 'Saving...' : 'Save Changes' }}</button>
        <button class="btn-outline" @click="editMode = false">Cancel</button>
      </div>
    </div>
    <div class="stat-grid sm">
      <div class="stat-card"><div class="stat-num">{{ applications.length }}</div><div class="stat-label">Applications</div></div>
      <div class="stat-card"><div class="stat-num">{{ applications.filter(a => a.status === 'selected').length }}</div><div class="stat-label">Selected</div></div>
      <div class="stat-card"><div class="stat-num">{{ applications.filter(a => a.status === 'interview').length }}</div><div class="stat-label">Interviews</div></div>
    </div>
  </div>
  <div v-if="activeTab === 'drives'">
    <div class="search-bar"><input v-model="searchDrive" placeholder="Search drives or companies..." @input="loadDrives" /></div>
    <div class="drive-grid">
      <div class="drive-card" v-for="dr in drives" :key="dr.id">
        <div class="drive-card-top">
          <h4>{{ dr.job_title }}</h4>
          <span class="drive-company">{{ dr.company_name }}</span>
        </div>
        <p class="drive-desc">{{ dr.job_description }}</p>
        <div class="drive-meta">
          <span v-if="dr.eligibility_criteria">Eligibility: {{ dr.eligibility_criteria }}</span>
          <span v-if="dr.deadline">Deadline: {{ dr.deadline.split('T')[0] }}</span>
        </div>
        <div class="drive-actions">
          <button class="btn-sm" @click="openDriveDetail(dr)">Details</button>
          <button v-if="!dr.already_applied" class="btn-primary sm" @click="applyDrive(dr.id)">Apply</button>
          <span v-else class="badge applied">Applied</span>
        </div>
      </div>
      <p v-if="drives.length === 0" class="empty">No approved drives available</p>
    </div>
  </div>
  <div v-if="activeTab === 'history'">
    <div class="table-wrap">
      <table>
        <thead><tr><th>Company</th><th>Drive</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
          <tr v-for="ap in applications" :key="ap.id">
            <td>{{ ap.company_name }}</td>
            <td>{{ ap.job_title }}</td>
            <td><span :class="['badge', ap.status]">{{ ap.status }}</span></td>
            <td>{{ ap.date ? ap.date.split('T')[0] : '-' }}</td>
          </tr>
        </tbody>
      </table>
      <p v-if="applications.length === 0" class="empty">No applications yet</p>
    </div>
  </div>
  <div v-if="modal.show" class="modal-overlay" @click.self="closeModal">
    <div class="modal-box">
      <button class="modal-close" @click="closeModal">&times;</button>
      <h3>{{ modal.data.job_title }}</h3>
      <div class="detail-row"><span>Company</span><span>{{ modal.data.company_name }}</span></div>
      <div class="detail-row"><span>Description</span><span>{{ modal.data.job_description }}</span></div>
      <div class="detail-row"><span>Eligibility</span><span>{{ modal.data.eligibility_criteria }}</span></div>
      <div class="detail-row"><span>Deadline</span><span>{{ modal.data.deadline ? modal.data.deadline.split('T')[0] : '-' }}</span></div>
      <button v-if="!modal.data.already_applied" class="btn-primary full" @click="applyDrive(modal.data.id); closeModal()">Apply Now</button>
      <span v-else class="badge applied">Already Applied</span>
    </div>
  </div>
</div>  
</template>
