from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from flask import request, jsonify, make_response
from app import bp, db, app, redis_client, celery_app, mail
from app.models import User, Company, Student, Placement_Drive, Application
from flask_mail import Message
from datetime import datetime, timezone
import json, csv, io, requests, os, uuid

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in app.config["ALLOWED_EXTENSIONS"]

def save_resume(file):
    if not file or file.filename == "":
        return ""
    if not allowed_file(file.filename):
        return None
    ext = file.filename.rsplit(".", 1)[1].lower()
    unique_name = f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(app.config["UPLOAD_FOLDER"], unique_name))
    return unique_name

def cache_get(key):
    data = redis_client.get(key)
    if data:
        return json.loads(data)
    return None

def cache_set(key, value, ttl=None):
    if ttl is None:
        ttl = app.config["CACHE_TTL"]
    redis_client.setex(key, ttl, json.dumps(value))

def cache_delete_pattern(pattern):
    keys = redis_client.keys(pattern)
    if keys:
        redis_client.delete(*keys)

@bp.route("/auth/login", methods=["POST"])
def login():    
    data = request.get_json()
    email = data.get("email", "")
    password = data.get("password", "")
    user = db.session.execute(db.select(User).filter_by(email=email)).scalar_one_or_none()
    if not user or not check_password_hash(user.password, password):
        return jsonify({"msg": "Invalid email or password"}), 401
    if not user.is_active:
        return jsonify({"msg": "Account is deactivated"}), 403
    extra = {}
    if user.role == "company":
        comp = db.session.execute(db.select(Company).filter_by(company_id=user.id)).scalar_one_or_none()
        if comp:
            extra["company_id"] = comp.id
            extra["approval_status"] = comp.approval_status
            if comp.is_blacklisted:
                return jsonify({"msg": "Your company has been blacklisted"}), 403
    if user.role == "student":
        stu = db.session.execute(db.select(Student).filter_by(student_id=user.id)).scalar_one_or_none()
        if stu:
            extra["student_id"] = stu.id
            if stu.is_blacklisted:
                return jsonify({"msg": "Your account has been blacklisted"}), 403
    token = create_access_token(identity=str(user.id), additional_claims={"role": user.role})
    return jsonify({"token": token, "role": user.role, "name": user.name, **extra}), 200

@bp.route("/auth/register/student", methods=["POST"])
def register_student():
    data = request.form
    if db.session.execute(db.select(User).filter_by(email=data["email"])).scalar_one_or_none():
        return jsonify({"msg": "Email already registered"}), 409
    resume_name = ""
    if "resume" in request.files:
        result = save_resume(request.files["resume"])
        if result is None:
            return jsonify({"msg": "Only PDF, DOC, DOCX files are allowed"}), 400
        resume_name = result
    user = User(email=data["email"], password=generate_password_hash(data["password"]), name=data["name"], role="student", is_active=True)
    db.session.add(user)
    db.session.flush()
    student = Student(student_id=user.id, student_name=data["name"], department=data.get("department", ""), year=int(data.get("year", 1)), cgpa=float(data.get("cgpa", 0.0)), resume_path=resume_name, is_blacklisted=False)
    db.session.add(student)
    db.session.commit()
    cache_delete_pattern("admin_stats*")
    cache_delete_pattern("all_students*")
    return jsonify({"msg": "Student registered successfully"}), 201

@bp.route("/auth/register/company", methods=["POST"])
def register_company():
    data = request.get_json()
    if db.session.execute(db.select(User).filter_by(email=data["email"])).scalar_one_or_none():
        return jsonify({"msg": "Email already registered"}), 409
    user = User(email=data["email"], password=generate_password_hash(data["password"]), name=data["company_name"], role="company", is_active=True)
    db.session.add(user)
    db.session.flush()
    company = Company(company_id=user.id, company_name=data["company_name"], hr_contact=data.get("hr_contact", ""), website=data.get("website", ""), approval_status="pending", is_blacklisted=False)
    db.session.add(company)
    db.session.commit()
    cache_delete_pattern("admin_stats*")
    cache_delete_pattern("all_companies*")
    return jsonify({"msg": "Company registered. Awaiting admin approval."}), 201

@bp.route("/admin/stats", methods=["GET"])
@jwt_required()
def admin_stats():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    cached = cache_get("admin_stats")
    if cached:
        return jsonify(cached), 200
    total_students = db.session.query(Student).count()
    total_companies = db.session.query(Company).count()
    total_drives = db.session.query(Placement_Drive).count()
    total_applications = db.session.query(Application).count()
    pending_companies = db.session.query(Company).filter_by(approval_status="pending").count()
    pending_drives = db.session.query(Placement_Drive).filter_by(status="pending").count()
    result = {"total_students": total_students, "total_companies": total_companies, "total_drives": total_drives, "total_applications": total_applications, "pending_companies": pending_companies, "pending_drives": pending_drives}
    cache_set("admin_stats", result)
    return jsonify(result), 200

@bp.route("/admin/companies", methods=["GET"])
@jwt_required()
def admin_companies():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    search = request.args.get("search", "")
    cache_key = f"all_companies_{search}"
    cached = cache_get(cache_key)
    if cached:
        return jsonify(cached), 200
    query = db.session.query(Company)
    if search:
        query = query.filter(Company.company_name.ilike(f"%{search}%"))
    companies = query.all()
    result = [{"id": c.id, "company_id": c.company_id, "company_name": c.company_name, "hr_contact": c.hr_contact, "website": c.website, "approval_status": c.approval_status, "is_blacklisted": c.is_blacklisted} for c in companies]
    cache_set(cache_key, result)
    return jsonify(result), 200

@bp.route("/admin/students", methods=["GET"])
@jwt_required()
def admin_students():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    search = request.args.get("search", "")
    cache_key = f"all_students_{search}"
    cached = cache_get(cache_key)
    if cached:
        return jsonify(cached), 200
    query = db.session.query(Student)
    if search:
        query = query.filter(Student.student_name.ilike(f"%{search}%"))
    students = query.all()
    result = [{"id": s.id, "student_id": s.student_id, "student_name": s.student_name, "department": s.department, "year": s.year, "cgpa": s.cgpa, "resume_path": s.resume_path, "is_blacklisted": s.is_blacklisted} for s in students]
    cache_set(cache_key, result)
    return jsonify(result), 200

@bp.route("/admin/drives", methods=["GET"])
@jwt_required()
def admin_drives():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    cached = cache_get("all_drives_admin")
    if cached:
        return jsonify(cached), 200
    drives = db.session.query(Placement_Drive).all()
    result = [{"id": d.id, "company_id": d.company_id, "company_name": d.company.company_name, "job_title": d.job_title, "job_description": d.job_description, "eligibility_criteria": d.eligibility_criteria, "deadline": d.deadline.isoformat() if d.deadline else None, "status": d.status, "applicant_count": len(d.applications)} for d in drives]
    cache_set("all_drives_admin", result)
    return jsonify(result), 200

@bp.route("/admin/applications", methods=["GET"])
@jwt_required()
def admin_applications():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    cached = cache_get("all_applications_admin")
    if cached:
        return jsonify(cached), 200
    apps = db.session.query(Application).all()
    result = [{"id": a.id, "student_name": a.student.student_name, "drive_title": a.drive.job_title, "company_name": a.drive.company.company_name, "status": a.status, "date": a.date.isoformat() if a.date else None} for a in apps]
    cache_set("all_applications_admin", result)
    return jsonify(result), 200

@bp.route("/admin/company/<int:cid>/approve", methods=["PUT"])
@jwt_required()
def approve_company(cid):
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    company = db.session.get(Company, cid)
    if not company:
        return jsonify({"msg": "Company not found"}), 404
    company.approval_status = "approved"
    db.session.commit()
    cache_delete_pattern("all_companies*")
    cache_delete_pattern("admin_stats*")
    return jsonify({"msg": "Company approved"}), 200

@bp.route("/admin/company/<int:cid>/reject", methods=["PUT"])
@jwt_required()
def reject_company(cid):
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    company = db.session.get(Company, cid)
    if not company:
        return jsonify({"msg": "Company not found"}), 404
    company.approval_status = "rejected"
    db.session.commit()
    cache_delete_pattern("all_companies*")
    cache_delete_pattern("admin_stats*")
    return jsonify({"msg": "Company rejected"}), 200

@bp.route("/admin/company/<int:cid>/blacklist", methods=["PUT"])
@jwt_required()
def blacklist_company(cid):
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    company = db.session.get(Company, cid)
    if not company:
        return jsonify({"msg": "Company not found"}), 404
    company.is_blacklisted = not company.is_blacklisted
    if company.is_blacklisted:
        company.approval_status = "blacklisted"
    else:
        company.approval_status = "approved"
    db.session.commit()
    cache_delete_pattern("all_companies*")
    cache_delete_pattern("admin_stats*")
    return jsonify({"msg": "Company blacklist status updated", "is_blacklisted": company.is_blacklisted}), 200

@bp.route("/admin/student/<int:sid>/blacklist", methods=["PUT"])
@jwt_required()
def blacklist_student(sid):
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    student = db.session.get(Student, sid)
    if not student:
        return jsonify({"msg": "Student not found"}), 404
    student.is_blacklisted = not student.is_blacklisted
    db.session.commit()
    cache_delete_pattern("all_students*")
    cache_delete_pattern("admin_stats*")
    return jsonify({"msg": "Student blacklist status updated", "is_blacklisted": student.is_blacklisted}), 200

@bp.route("/admin/drive/<int:did>/approve", methods=["PUT"])
@jwt_required()
def approve_drive(did):
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    drive = db.session.get(Placement_Drive, did)
    if not drive:
        return jsonify({"msg": "Drive not found"}), 404
    drive.status = "approved"
    db.session.commit()
    cache_delete_pattern("all_drives*")
    cache_delete_pattern("admin_stats*")
    cache_delete_pattern("approved_drives*")
    return jsonify({"msg": "Drive approved"}), 200

@bp.route("/admin/drive/<int:did>/reject", methods=["PUT"])
@jwt_required()
def reject_drive(did):
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    drive = db.session.get(Placement_Drive, did)
    if not drive:
        return jsonify({"msg": "Drive not found"}), 404
    drive.status = "rejected"
    db.session.commit()
    cache_delete_pattern("all_drives*")
    cache_delete_pattern("admin_stats*")
    cache_delete_pattern("approved_drives*")
    return jsonify({"msg": "Drive rejected"}), 200

@bp.route("/admin/reminder", methods=["POST"])
@jwt_required()
def send_reminder():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    data = request.get_json()
    webhook_url = data.get("webhook_url", "")
    if not webhook_url:
        return jsonify({"msg": "Webhook URL is required"}), 400
    result = send_deadline_reminder(webhook_url)
    return jsonify({"msg": result}), 200

@bp.route("/admin/activity-report", methods=["POST"])
@jwt_required()
def activity_report():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "admin":
        return jsonify({"msg": "Unauthorized"}), 403
    result = send_activity_report(user.email)
    return jsonify({"msg": result}), 200

@bp.route("/company/profile", methods=["GET"])
@jwt_required()
def company_profile():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "company":
        return jsonify({"msg": "Unauthorized"}), 403
    company = db.session.execute(db.select(Company).filter_by(company_id=user.id)).scalar_one_or_none()
    if not company:
        return jsonify({"msg": "Company profile not found"}), 404
    return jsonify({"id": company.id, "company_name": company.company_name, "hr_contact": company.hr_contact, "website": company.website, "approval_status": company.approval_status, "is_blacklisted": company.is_blacklisted, "email": user.email}), 200

@bp.route("/company/drives", methods=["GET"])
@jwt_required()
def company_drives():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "company":
        return jsonify({"msg": "Unauthorized"}), 403
    company = db.session.execute(db.select(Company).filter_by(company_id=user.id)).scalar_one_or_none()
    if not company:
        return jsonify({"msg": "Company not found"}), 404
    cache_key = f"company_drives_{company.id}"
    cached = cache_get(cache_key)
    if cached:
        return jsonify(cached), 200
    drives = db.session.query(Placement_Drive).filter_by(company_id=company.id).all()
    result = [{"id": d.id, "job_title": d.job_title, "job_description": d.job_description, "eligibility_criteria": d.eligibility_criteria, "deadline": d.deadline.isoformat() if d.deadline else None, "status": d.status, "applicant_count": len(d.applications)} for d in drives]
    cache_set(cache_key, result)
    return jsonify(result), 200

@bp.route("/company/drives", methods=["POST"])
@jwt_required()
def create_drive():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "company":
        return jsonify({"msg": "Unauthorized"}), 403
    company = db.session.execute(db.select(Company).filter_by(company_id=user.id)).scalar_one_or_none()
    if not company:
        return jsonify({"msg": "Company not found"}), 404
    if company.approval_status != "approved":
        return jsonify({"msg": "Company not approved by admin yet"}), 403
    if company.is_blacklisted:
        return jsonify({"msg": "Company is blacklisted"}), 403
    data = request.get_json()
    deadline_str = data.get("deadline", "")
    deadline = None
    if deadline_str:
        deadline = datetime.fromisoformat(deadline_str).replace(tzinfo=timezone.utc)
    drive = Placement_Drive(company_id=company.id, job_title=data["job_title"], job_description=data.get("job_description", ""), eligibility_criteria=data.get("eligibility_criteria", ""), deadline=deadline, status="pending")
    db.session.add(drive)
    db.session.commit()
    cache_delete_pattern(f"company_drives_{company.id}*")
    cache_delete_pattern("all_drives*")
    cache_delete_pattern("admin_stats*")
    cache_delete_pattern("approved_drives*")
    return jsonify({"msg": "Drive created. Awaiting admin approval.", "id": drive.id}), 201

@bp.route("/company/drive/<int:did>/applications", methods=["GET"])
@jwt_required()
def drive_applications(did):
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "company":
        return jsonify({"msg": "Unauthorized"}), 403
    company = db.session.execute(db.select(Company).filter_by(company_id=user.id)).scalar_one_or_none()
    drive = db.session.get(Placement_Drive, did)
    if not drive or drive.company_id != company.id:
        return jsonify({"msg": "Drive not found"}), 404
    apps = db.session.query(Application).filter_by(drive_id=did).all()
    result = [{"id": a.id, "student_id": a.student_id, "student_name": a.student.student_name, "department": a.student.department, "cgpa": a.student.cgpa, "year": a.student.year, "resume_path": a.student.resume_path, "status": a.status, "date": a.date.isoformat() if a.date else None} for a in apps]
    return jsonify(result), 200

@bp.route("/company/application/<int:aid>/status", methods=["PUT"])
@jwt_required()
def update_application_status(aid):
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "company":
        return jsonify({"msg": "Unauthorized"}), 403
    company = db.session.execute(db.select(Company).filter_by(company_id=user.id)).scalar_one_or_none()
    application = db.session.get(Application, aid)
    if not application:
        return jsonify({"msg": "Application not found"}), 404
    drive = db.session.get(Placement_Drive, application.drive_id)
    if drive.company_id != company.id:
        return jsonify({"msg": "Unauthorized"}), 403
    data = request.get_json()
    new_status = data.get("status", "")
    if new_status not in ["applied", "shortlisted", "interview", "selected", "rejected"]:
        return jsonify({"msg": "Invalid status"}), 400
    application.status = new_status
    db.session.commit()
    cache_delete_pattern("all_applications*")
    cache_delete_pattern(f"student_applications*")
    return jsonify({"msg": "Application status updated"}), 200

@bp.route("/student/profile", methods=["GET"])
@jwt_required()
def student_profile():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "student":
        return jsonify({"msg": "Unauthorized"}), 403
    student = db.session.execute(db.select(Student).filter_by(student_id=user.id)).scalar_one_or_none()
    if not student:
        return jsonify({"msg": "Student profile not found"}), 404
    return jsonify({"id": student.id, "student_name": student.student_name, "department": student.department, "year": student.year, "cgpa": student.cgpa, "resume_path": student.resume_path, "is_blacklisted": student.is_blacklisted, "email": user.email}), 200

@bp.route("/student/profile", methods=["PUT"])
@jwt_required()
def update_student_profile():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "student":
        return jsonify({"msg": "Unauthorized"}), 403
    student = db.session.execute(db.select(Student).filter_by(student_id=user.id)).scalar_one_or_none()
    if not student:
        return jsonify({"msg": "Student not found"}), 404
    data = request.form
    if "name" in data:
        student.student_name = data["name"]
        user.name = data["name"]
    if "department" in data:
        student.department = data["department"]
    if "year" in data:
        student.year = int(data["year"])
    if "cgpa" in data:
        student.cgpa = float(data["cgpa"])
    if "resume" in request.files:
        result = save_resume(request.files["resume"])
        if result is None:
            return jsonify({"msg": "Only PDF, DOC, DOCX files are allowed"}), 400
        if result:
            old_file = os.path.join(app.config["UPLOAD_FOLDER"], student.resume_path)
            if student.resume_path and os.path.exists(old_file):
                os.remove(old_file)
            student.resume_path = result
    db.session.commit()
    cache_delete_pattern("all_students*")
    return jsonify({"msg": "Profile updated"}), 200

@bp.route("/student/drives", methods=["GET"])
@jwt_required()
def student_drives():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "student":
        return jsonify({"msg": "Unauthorized"}), 403
    search = request.args.get("search", "")
    cache_key = f"approved_drives_{search}"
    cached = cache_get(cache_key)
    if cached:
        return jsonify(cached), 200
    query = db.session.query(Placement_Drive).filter_by(status="approved")
    if search:
        query = query.join(Company).filter((Placement_Drive.job_title.ilike(f"%{search}%")) | (Company.company_name.ilike(f"%{search}%")))
    drives = query.all()
    student = db.session.execute(db.select(Student).filter_by(student_id=user.id)).scalar_one_or_none()
    applied_ids = []
    if student:
        applied_ids = [a.drive_id for a in student.application]
    result = [{"id": d.id, "company_name": d.company.company_name, "job_title": d.job_title, "job_description": d.job_description, "eligibility_criteria": d.eligibility_criteria, "deadline": d.deadline.isoformat() if d.deadline else None, "already_applied": d.id in applied_ids} for d in drives]
    cache_set(cache_key, result, 120)
    return jsonify(result), 200

@bp.route("/student/apply/<int:did>", methods=["POST"])
@jwt_required()
def apply_drive(did):
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "student":
        return jsonify({"msg": "Unauthorized"}), 403
    student = db.session.execute(db.select(Student).filter_by(student_id=user.id)).scalar_one_or_none()
    if not student:
        return jsonify({"msg": "Student not found"}), 404
    if student.is_blacklisted:
        return jsonify({"msg": "You are blacklisted"}), 403
    drive = db.session.get(Placement_Drive, did)
    if not drive or drive.status != "approved":
        return jsonify({"msg": "Drive not available"}), 404
    if drive.deadline:
        dl = drive.deadline if drive.deadline.tzinfo else drive.deadline.replace(tzinfo=timezone.utc)
        if dl < datetime.now(timezone.utc):
            return jsonify({"msg": "Application deadline has passed"}), 400
    existing = db.session.query(Application).filter_by(student_id=student.id, drive_id=did).first()
    if existing:
        return jsonify({"msg": "Already applied to this drive"}), 409
    criteria = drive.eligibility_criteria
    if criteria:
        parts = [p.strip() for p in criteria.split(",")]
        for part in parts:
            part_lower = part.lower()
            if "cgpa" in part_lower:
                try:
                    min_cgpa = float(part_lower.replace("cgpa", "").replace(">=", "").replace(">", "").replace(":", "").strip())
                    if student.cgpa < min_cgpa:
                        return jsonify({"msg": f"Minimum CGPA required: {min_cgpa}"}), 400
                except ValueError:
                    pass
            if "year" in part_lower:
                try:
                    req_year = int(part_lower.replace("year", "").replace(">=", "").replace("=", "").replace(":", "").strip())
                    if student.year < req_year:
                        return jsonify({"msg": f"Minimum year required: {req_year}"}), 400
                except ValueError:
                    pass
    application = Application(student_id=student.id, drive_id=did, date=datetime.now(timezone.utc), status="applied")
    db.session.add(application)
    db.session.commit()
    cache_delete_pattern("approved_drives*")
    cache_delete_pattern("student_applications*")
    cache_delete_pattern("all_applications*")
    cache_delete_pattern("admin_stats*")
    cache_delete_pattern(f"company_drives*")
    return jsonify({"msg": "Application submitted successfully"}), 201

@bp.route("/student/applications", methods=["GET"])
@jwt_required()
def student_applications():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "student":
        return jsonify({"msg": "Unauthorized"}), 403
    student = db.session.execute(db.select(Student).filter_by(student_id=user.id)).scalar_one_or_none()
    if not student:
        return jsonify({"msg": "Student not found"}), 404
    cache_key = f"student_applications_{student.id}"
    cached = cache_get(cache_key)
    if cached:
        return jsonify(cached), 200
    apps = db.session.query(Application).filter_by(student_id=student.id).all()
    result = [{"id": a.id, "drive_id": a.drive_id, "company_name": a.drive.company.company_name, "job_title": a.drive.job_title, "status": a.status, "date": a.date.isoformat() if a.date else None} for a in apps]
    cache_set(cache_key, result, 120)
    return jsonify(result), 200

@bp.route("/student/export-csv", methods=["GET"])
@jwt_required()
def export_csv():
    uid = get_jwt_identity()
    user = db.session.get(User, int(uid))
    if not user or user.role != "student":
        return jsonify({"msg": "Unauthorized"}), 403
    student = db.session.execute(db.select(Student).filter_by(student_id=user.id)).scalar_one_or_none()
    if not student:
        return jsonify({"msg": "Student not found"}), 404
    apps = db.session.query(Application).filter_by(student_id=student.id).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Student ID", "Company Name", "Drive Title", "Application Status", "Date"])
    for a in apps:
        writer.writerow([student.id, a.drive.company.company_name, a.drive.job_title, a.status, a.date.strftime("%Y-%m-%d") if a.date else ""])
    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = "attachment; filename=placement_history.csv"
    response.headers["Content-Type"] = "text/csv"
    return response

@celery_app.task
def send_deadline_reminder(webhook_url):
    with app.app_context():
        upcoming = db.session.query(Placement_Drive).filter(Placement_Drive.status == "approved", Placement_Drive.deadline != None, Placement_Drive.deadline > datetime.now(timezone.utc)).all()
        if not upcoming:
            return "No upcoming drives"
        lines = []
        for d in upcoming:
            lines.append(f"*{d.job_title}* by {d.company.company_name} - Deadline: {d.deadline.strftime('%Y-%m-%d %H:%M')}")
        text = "*Upcoming Placement Drive Deadlines*\n\n" + "\n".join(lines)
        requests.post(webhook_url, json={"text": text})
        return "Reminder sent"

@celery_app.task
def send_activity_report(admin_email):
    with app.app_context():
        total_drives = db.session.query(Placement_Drive).count()
        total_applied = db.session.query(Application).count()
        total_selected = db.session.query(Application).filter_by(status="selected").count()
        html_body = f"""<html>
<head><style>body{{font-family:Arial,sans-serif;padding:20px;background:#f4f6f8}}
.card{{background:#fff;border-radius:8px;padding:24px;max-width:500px;margin:auto;box-shadow:0 2px 8px rgba(0,0,0,0.1)}}
h2{{color:#1a73e8;margin-bottom:20px}}
.stat{{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid #e0e0e0}}
.stat:last-child{{border-bottom:none}}
.label{{font-weight:600;color:#333}}
.value{{color:#1a73e8;font-size:18px;font-weight:700}}</style></head>
<body><div class="card">
<h2>CareerNexus Activity Report</h2>
<div class="stat"><span class="label">Drives Conducted</span><span class="value">{total_drives}</span></div>
<div class="stat"><span class="label">Students Applied</span><span class="value">{total_applied}</span></div>
<div class="stat"><span class="label">Students Selected</span><span class="value">{total_selected}</span></div>
</div></body></html>"""
        msg = Message(subject="CareerNexus Activity Report", recipients=[admin_email], html=html_body)
        mail.send(msg)
        return "Report sent"