from sqlalchemy import ForeignKey, Column, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import List
from app import db

class User(db.Model):
    __tablename__ = "users" 
    id: Mapped[int] = mapped_column(primary_key = True)
    email: Mapped[str] = mapped_column(unique = True) 
    password: Mapped[str]= mapped_column()
    name: Mapped[str] = mapped_column()
    role: Mapped[str] = mapped_column()
    is_active: Mapped[bool] = mapped_column()

    company: Mapped["Company"] = relationship("Company", back_populates = "user", uselist = False)
    student: Mapped["Student"] = relationship("Student", back_populates = "user", uselist = False)

class Company(db.Model):
    __tablename__ = "companies"
    id: Mapped[int] = mapped_column(primary_key = True)
    company_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    company_name: Mapped[str] = mapped_column()
    hr_contact: Mapped[str] = mapped_column()
    website: Mapped[str] = mapped_column()
    approval_status: Mapped[str] = mapped_column(default = "pending") #approve, pending, reject, blacklist
    is_blacklisted: Mapped[bool] = mapped_column()

    user: Mapped["User"] = relationship("User", back_populates = "company")
    drive: Mapped[List["Placement_Drive"]] = relationship("Placement_Drive", back_populates = "company")

class Student(db.Model):
    __tablename__ = "students"
    id: Mapped[int] = mapped_column(primary_key = True)
    student_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    student_name: Mapped[str] = mapped_column()
    department: Mapped[str] = mapped_column()
    year: Mapped[int] = mapped_column()
    cgpa: Mapped[float] = mapped_column()
    resume_path: Mapped[str] = mapped_column()
    is_blacklisted: Mapped[bool] = mapped_column()

    user: Mapped["User"] = relationship("User", back_populates = "student")
    application: Mapped[List["Application"]] = relationship("Application", back_populates = "student")

class Placement_Drive(db.Model):
    __tablename__ = "drives"
    id: Mapped[int] = mapped_column(primary_key = True)
    company_id: Mapped[int] = mapped_column(ForeignKey("companies.id"))
    job_title: Mapped[str] = mapped_column()
    job_description: Mapped[str] = mapped_column()
    eligibility_criteria: Mapped[str] = mapped_column() # branch/cgpa/year
    deadline = Column(DateTime(timezone = True))
    status: Mapped[str] = mapped_column(default = "pending") # pending, approve, reject

    company: Mapped["Company"] = relationship("Company", back_populates = "drive")
    applications: Mapped[List["Application"]] = relationship("Application", back_populates = "drive")

class Application(db.Model):
    __tablename__ = "applications"
    id: Mapped[int] = mapped_column(primary_key = True)
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id"))
    drive_id: Mapped[int] = mapped_column(ForeignKey("drives.id"))
    date = Column(DateTime(timezone = True))
    status: Mapped[str] = mapped_column(default = "applied") # applied, shortlisted, selected, rejected

    student: Mapped["Student"] = relationship("Student", back_populates = "application")
    drive: Mapped["Placement_Drive"] = relationship("Placement_Drive", back_populates = "applications")







