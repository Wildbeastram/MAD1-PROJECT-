from flask import Flask, Blueprint, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_mail import Mail
from flask_cors import CORS
from sqlalchemy.orm import DeclarativeBase
from werkzeug.security import generate_password_hash
from celery import Celery
import redis
import os

class Base(DeclarativeBase):
  pass

app = Flask(__name__)
bp = Blueprint('api', __name__, url_prefix='/api')
from .config import Config
app.config.from_object(Config)
db = SQLAlchemy(model_class=Base)
jwt = JWTManager(app)
mail = Mail(app)
CORS(app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)
db.init_app(app)
redis_client = redis.Redis.from_url(app.config["REDIS_URL"], decode_responses=True)
celery_app = Celery(app.name, broker=app.config["CELERY_BROKER_URL"], backend=app.config["CELERY_RESULT_BACKEND"])
celery_app.conf.update(app.config)

from .models import User
def admin():
  email = "admin@gmail.com"
  existing = db.session.execute(db.select(User).filter_by(email = email)).scalar_one_or_none()
  if existing:
    return {"message": "Admin account is already created"}
  add_admin = User(email = email, password = generate_password_hash("admin"), name = "admin", role = "admin", is_active = True)
  db.session.add(add_admin)
  print("Admin created successfully")
  db.session.commit()
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

@app.route("/uploads/resumes/<path:filename>")
def serve_resume(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)
from .routes import *
app.register_blueprint(bp)
