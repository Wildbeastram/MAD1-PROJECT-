from app import app, db, admin

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        admin()
    app.run(debug = True, port = 5000)